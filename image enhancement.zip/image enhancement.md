```python
import cv2
import matplotlib.pyplot as plt 
```


```python
img = plt.imread('birds.jpg') #reads image data
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x25f10852848>




![png](output_2_1.png)



```python
histr = cv2.calcHist([img],[0],None,[256],[0,256])
```


```python
plt.plot(histr)
plt.show()
```


![png](output_4_0.png)



```python

```


```python

```


```python

```


```python

```
